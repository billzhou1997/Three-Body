//Programmer:  Bill Zhou zhou.2723@osu.edu
// Revision history:
//  04-April-2020 original idea of the program structure
//  17-April-2020 original version 
//  24-April-2020 First draft of the whole program
//  1-May-2020 Error Analysis added
//  3-May-2020 Second half of Error Analysis added
//Here is another copy of my main project
//Add the loop to see how far the distance D goes VS different steplength t,given the same step N=1000
//The comments below is the second part of my error analysis.
// the data file of the output from this program only display the final distance of ball[0] with default ICs in terms of two different algorithms looping from t=0.001 to t=0.1 with step  delta t =0.001, are named as Euler_error.dat & Frog_error.dat
//As we can see from the plot Euler_error.ps, in general D vs t is a linear curve. D proportional to the final distance given the same step number. which consists with my expectation
//As for the plot Frog_error.ps, there is no explicit rule of the data points, the only tendency we can observe is that still in general the relative error growth with the increase of t. Besides, compared with Euler algorithm, Frog Leap has considerable small relative error in general.
// After that I modified my code and loop over 0.00000001 to 0.1 with 2 multipler, provided same total time, data stored in Euler_error2.dat &Frog_error2.dat
// Plots named as Euler_error2.dat & Frog_error2.dat
// In this case, still we can observe that for Euler method,as t increase, D increase as well
// However, for FrogLeap, D does not increase with t until t growth to about 10^-8
//Thus my conclude here is that:
//1)For FrogLeap, which is a second order methods, there is no point to set t smaller than 10^-8, since 10^-16 is where round-off error dominates.
//2)For Euler algorithm, we should take as tiny steps as we can between the interval t=10^-9 to 0.1, there is no meaning to dig out further behaviors for t even smaller than 10^-9 because definitely we can increase the precision a little bit by set tiny t, but the total running time of my program is going to be exponantial blow up
//For my selection of loop coefficient, it's already a few minutes running time, thus I don't want to do further experiment, and my assuption here is that relative error is going to keep diminishing with the decrease of t, until t=10^-16, which reach the limit of double precision.



#include <iostream>		// note that .h is omitted
#include <iomanip>		// note that .h is omitted
#include <fstream>		// note that .h is omitted
using namespace std;		// we need this when .h is omitted
#include <cmath>
struct ball			// define a type to hold parameters 
{
  double m;			// mass of particle 
  double x, y;			// location of the ball 
  double v_x, v_y;		// velocity of the ball
};
double force_x (struct ball &a, struct ball &b);
double force_y (struct ball &a, struct ball &b);
double distance (struct ball &a);
int
main ()
{
  double T = 10;		// program running time
  ofstream out;
  struct ball ball[3];		//create objects
  ball[0].x = 1;
  ball[0].y = 0;
  ball[0].v_x = 0;
  ball[0].v_y = 0.5;
  ball[0].m = 1;

  ball[1].x = -1;
  ball[1].y = -0;
  ball[1].m = 1;
  ball[1].v_x = 0;
  ball[1].v_y = -0.5;

  ball[2].x = 0;
  ball[2].y = 0;
  ball[2].m = 0.00000001;
  ball[2].v_x = 0;
  ball[2].v_y = 0;
  int answer2 = 2;		//answer to continue query 
  while (answer2 != 0)		// iterate until told to move on 
    {
      int answer = 1;
      while (answer != 0)	// iterate until told to move on 
	{
	  cout << "\nCurrent parameters:\n";
	  cout << " [1] x0 = " << setprecision (5) << ball[0].x << "\t";
	  cout << "[2] y0 = " << setprecision (5) << ball[0].y << "\t";
	  cout << "[3] vx0 = " << setprecision (5) << ball[0].v_x << "\t";
	  cout << " [4] vy0 = " << setprecision (5) << ball[0].v_y << "\t";
	  cout << "[5] m0 = " << setprecision (5) << ball[0].m << endl;
	  cout << " [6] x1 = " << setprecision (5) << ball[1].x << "\t";
	  cout << "[7] y1 = " << setprecision (5) << ball[1].y << "\t";
	  cout << "[8] vx1 = " << setprecision (5) << ball[1].v_x << "\t";
	  cout << " [9] vy1 = " << setprecision (5) << ball[1].v_y << "\t";
	  cout << "[10] m1 = " << setprecision (5) << ball[1].m << endl;
	  cout << " [11] x2 = " << setprecision (5) << ball[2].x << "\t";
	  cout << "[12] y2 = " << setprecision (5) << ball[2].y << "\t";
	  cout << "[13] vx2 = " << setprecision (5) << ball[2].v_x << "\t";
	  cout << " [14] vy2 = " << setprecision (5) << ball[2].v_y << "\t";
	  cout << "[15] m2 = " << setprecision (5) << ball[2].m << endl;
	  cout << "\nWhat do you want to change? [0 for none] ";
	  cin >> answer;
	  cout << endl;

	  switch (answer)
	    {
	    case 0:
	      break;
	    case 1:
	      cout << " enter x0: ";
	      cin >> ball[0].x;
	      break;
	    case 2:
	      cout << " enter y0: ";
	      cin >> ball[0].y;
	      break;
	    case 3:
	      cout << " enter vx0: ";
	      cin >> ball[0].v_x;
	      break;
	    case 4:
	      cout << " enter vy0: ";
	      cin >> ball[0].v_y;
	      break;
	    case 5:
	      cout << " enter m0: ";
	      cin >> ball[0].m;
	      break;
	    case 6:
	      cout << " enter x1: ";
	      cin >> ball[1].x;
	      break;
	    case 7:
	      cout << " enter y1: ";
	      cin >> ball[1].y;
	      break;
	    case 8:
	      cout << " enter vx1: ";
	      cin >> ball[1].v_x;
	      break;
	    case 9:
	      cout << " enter vy1: ";
	      cin >> ball[1].v_y;
	      break;
	    case 10:
	      cout << " enter m1: ";
	      cin >> ball[1].m;
	      break;
	    case 11:
	      cout << " enter x2: ";
	      cin >> ball[2].x;
	      break;
	    case 12:
	      cout << " enter y2: ";
	      cin >> ball[2].y;
	      break;
	    case 13:
	      cout << " enter vx2: ";
	      cin >> ball[2].v_x;
	      break;
	    case 14:
	      cout << " enter vy2: ";
	      cin >> ball[2].v_y;
	      break;
	    case 15:
	      cout << " enter m2: ";
	      cin >> ball[2].m;
	      break;
	    
	    
	    default:
	      break;
	    }
	}			//initializing conditions

      if (answer2 == 2)		// open a new file
	{
	  out.open ("final_error.dat", ofstream::trunc);
	}
      else			// append
	{
	  out.open ("final_error.dat", ofstream::app);
	}
      double a_0_x =
	(force_x (ball[0], ball[1]) + force_x (ball[0], ball[2])) / ball[0].m;
      double a_0_y =
	(force_y (ball[0], ball[1]) + force_y (ball[0], ball[2])) / ball[0].m;
      double a_1_x =
	(force_x (ball[1], ball[0]) + force_x (ball[1], ball[2])) / ball[1].m;
      double a_1_y =
	(force_y (ball[1], ball[0]) + force_y (ball[1], ball[2])) / ball[1].m;
      double a_2_x =
	(force_x (ball[2], ball[0]) + force_x (ball[2], ball[1])) / ball[2].m;
      double a_2_y = (force_y (ball[2], ball[0]) + force_y (ball[2], ball[1])) / ball[2].m;	// creating acceleration variable

      /* for (double time1 = 0; time1 < 10; time1 += t)
         {
         ball[0].x += t * ball[0].v_x;
         ball[0].y += t * ball[0].v_y;
         a_0_x = force_x (ball[0], ball[2]) / ball[0].m;
         a_0_y = force_y (ball[0], ball[2]) / ball[0].m;
         ball[0].v_x += t * a_0_x;
         ball[0].v_y += t * a_0_y;
         out << time1 << " " << ball[0].x << " " << ball[0].y << endl;
         }                           circular orbit testing */
      int answer3 = 0;
      cout << "Select algorithm,1 for Euler,2 for Frog Leap" << endl;
      cin >> answer3;
    
for( double t=0.00000001;t<0.1;t*=2)//loop over different t
    {  if (answer3 == 2)
	{

	  ball[0].v_x += 0.5 * t * a_0_x;
	  ball[0].v_y += 0.5 * t * a_0_y;
	  ball[1].v_x += 0.5 * t * a_1_x;
	  ball[1].v_y += 0.5 * t * a_1_y;
	  ball[2].v_x += 0.5 * t * a_2_x;
	  ball[2].v_y += 0.5 * t * a_2_y;
	  for (double time= 0; time < T; time+=t)
	    {

	      ball[0].x += t * ball[0].v_x;
	      ball[0].y += t * ball[0].v_y;
	      ball[1].x += t * ball[1].v_x;
	      ball[1].y += t * ball[1].v_y;
	      ball[2].x += t * ball[2].v_x;
	      ball[2].y += t * ball[2].v_y;	//update position of balls
	      a_0_x =
		(force_x (ball[0], ball[1]) +
		 force_x (ball[0], ball[2])) / ball[0].m;
	      a_0_y =
		(force_y (ball[0], ball[1]) +
		 force_y (ball[0], ball[2])) / ball[0].m;
	      a_1_x =
		(force_x (ball[1], ball[0]) +
		 force_x (ball[1], ball[2])) / ball[1].m;
	      a_1_y =
		(force_y (ball[1], ball[0]) +
		 force_y (ball[1], ball[2])) / ball[1].m;
	      a_2_x =
		(force_x (ball[2], ball[0]) +
		 force_x (ball[2], ball[1])) / ball[2].m;
	      a_2_y = (force_y (ball[2], ball[0]) + force_y (ball[2], ball[1])) / ball[2].m;	//update acceleration of balls 
	      ball[1].v_x += t * a_1_x;
	      ball[1].v_y += t * a_1_y;
	      ball[0].v_x += t * a_0_x;
	      ball[0].v_y += t * a_0_y;
	      ball[2].v_x += t * a_2_x;
	      ball[2].v_y += t * a_2_y;	//update velocity of balls
	      //cout<< time<<" "<<ball[0].x<<" "<< ball[0].v_x<<" "<< a_0_x<<" "<<force_x(ball[0], ball[1])<<" "<<force_x(ball[0], ball[2])<<" "<< ball[0].x << " " <<  ball[0].y<< " "<< ball[1].x << " " <<  ball[1].y<< " "<< ball[2].x << " " <<  ball[2].y<< " "<<endl;
if(time>=9.8){
	     out << fixed << setprecision (10) << t<<" "<< distance (ball[0]) << endl;
break;
}
	    }
	}
else if(answer3==1){
      for (double time2= 0; time2 < T; time2+=t)
	{
	  a_0_x =
	    (force_x (ball[0], ball[1]) +
	     force_x (ball[0], ball[2])) / ball[0].m;
	  a_0_y =
	    (force_y (ball[0], ball[1]) +
	     force_y (ball[0], ball[2])) / ball[0].m;
	  a_1_x =
	    (force_x (ball[1], ball[0]) +
	     force_x (ball[1], ball[2])) / ball[1].m;
	  a_1_y =
	    (force_y (ball[1], ball[0]) +
	     force_y (ball[1], ball[2])) / ball[1].m;
	  a_2_x =
	    (force_x (ball[2], ball[0]) +
	     force_x (ball[2], ball[1])) / ball[2].m;
	  a_2_y = (force_y (ball[2], ball[0]) + force_y (ball[2], ball[1])) / ball[2].m;	//update acceleration of balls 
	  ball[0].x += t * ball[0].v_x;
	  ball[0].y += t * ball[0].v_y;
	  ball[1].x += t * ball[1].v_x;
	  ball[1].y += t * ball[1].v_y;
	  ball[2].x += t * ball[2].v_x;
	  ball[2].y += t * ball[2].v_y;	//update position of balls

	  ball[1].v_x += t * a_1_x;
	  ball[1].v_y += t * a_1_y;
	  ball[0].v_x += t * a_0_x;
	  ball[0].v_y += t * a_0_y;
	  ball[2].v_x += t * a_2_x;
	  ball[2].v_y += t * a_2_y;	//update velocity of balls
	  //cout<< time<<" "<<ball[0].x<<" "<< ball[0].v_x<<" "<< a_0_x<<" "<<force_x(ball[0], ball[1])<<" "<<force_x(ball[0], ball[2])<<" "<< ball[0].x << " " <<  ball[0].y<< " "<< ball[1].x << " " <<  ball[1].y<< " "<< ball[2].x << " " <<  ball[2].y<< " "<<endl;

	if(time2>=9.8){
	      out << fixed << setprecision (10) << t<<" "<< distance (ball[0]) << endl;
 break;
}
}
}

	}
      cout << " data stored in final_error.dat" << endl;
      out.close ();
      cout << "Again? (no=0, append=1, clear=2) ";
      cin >> answer2;
//double f =force_x(ball[0], ball[1]);

/*for(int i=0;i<2;i++)
{

f_2_y+=force_y(ball[i], ball[2]);
cout<< f_2_y<< endl;
}
cout<< ball[1].x<< endl;
cout<< f << endl;
*/
    }
  return 0;
}







double
force_x (struct ball &a, struct ball &b)	//force from b to a, x direction component
{
  double G = 1;
  double F =
    G * a.m * b.m / ((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
  double F_x =
    -F * (a.x -
	  b.x) / sqrt (((a.x - b.x) * (a.x - b.x) +
			(a.y - b.y) * (a.y - b.y)));
  return F_x;
};

double
force_y (struct ball &a, struct ball &b)	//force from b to a, y direction component
{
  double G = 1;
  double F =
    G * a.m * b.m / ((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
  double F_y =
    -F * (a.y -
	  b.y) / sqrt (((a.x - b.x) * (a.x - b.x) +
			(a.y - b.y) * (a.y - b.y)));
  return F_y;
};

double
distance (struct ball &a)
{
  double D;
  D = sqrt ((a.x * a.x) + (a.y * a.y));
  return D;
}

//ball[0][0] ball[0][0.1]
