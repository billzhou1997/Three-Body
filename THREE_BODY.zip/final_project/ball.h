class ball
{ 
  public:
    ball (const double rad);  // constructor
    ~ball ();  // destructor

    // accessor functions
    double get_radius ();
    void set_radius (const double rad);
    double area ();
    double circumference();
  private:
    double radius;  // the circle radius
    inline double sqr (const double x) {return x*x;};  // inline function
};

